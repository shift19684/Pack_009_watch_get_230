from awsiot import mqtt_connection_builder
import time
from datetime import datetime, timezone, timedelta
import sys
import json



ENDPOINT = "dxi-iot-endpoint.cvda.qa-ph3.dconnect2.daihatsu.co.jp"
CLIENT_ID = "SHIFT230-dcm28"
TOPIC="$aws/things/SHIFT230-dcm28/shadow/get"
PATH_TO_CERTIFICATE = "crt/crt/certificate.pem.crt"
PATH_TO_PRIVATE_KEY = "crt/crt/private.pem.key"
PATH_TO_AMAZON_ROOT_CA_1 = "crt/crt/aws-ca.pem"

#MESSAGE = "get_message"
MESSAGE = {}

RETRIES = 3 #times
INTERVAL = 9 #seconds
TIMEOUT = 5 #seconds

TIME_OFFSET = 9 #hours UTC+9 time offset

# Create a +9 hour offset
jst_tz = timezone(timedelta(hours=TIME_OFFSET))




limit = datetime(2026,5,29,0,0)
current = datetime.now() # no time offset

print("time : ", datetime.now(jst_tz))

if current > limit:
    print("beyond limit")
    sys.exit()
else:
    print("entering program") 


print("try to send the following message:")
json_string = json.dumps(MESSAGE)
print(json_string)


mqtt_connection = mqtt_connection_builder.mtls_from_path(
    endpoint=ENDPOINT,
    cert_filepath=PATH_TO_CERTIFICATE,
    pri_key_filepath=PATH_TO_PRIVATE_KEY,
    ca_filepath=PATH_TO_AMAZON_ROOT_CA_1,
    client_id=CLIENT_ID,
    clean_session=False,
    keep_alive_secs=120
)

#
#
# try connection
#
try:
    #
    connect_future = mqtt_connection.connect()
    print("time : ", datetime.now(jst_tz))
    # result() waits until a result is available
    connect_future.result(timeout=TIMEOUT)
    print(f'{CLIENT_ID} is connected to {TOPIC}')
except Exception as e:
        #
        print(f"Connection exception: {e}")
#
#
#Simple pause
input("Press ENTER to publish ... ")


#
# Publishing 
#

from awscrt import mqtt


print("time : ", datetime.now(jst_tz))
print(f"Publishing to {TOPIC} ...")


attempt = 1
while attempt <= RETRIES+1:
    #
    # try connection
    try:
        #connection
        connect_future = mqtt_connection.connect()
        connect_future.result(timeout=TIMEOUT)
        print("time : ", datetime.now(jst_tz))
        print("Connected successfully!")
        #
    except Exception as e:
        #
        print(f"Connection exception: {e}")
    #
    # try publish    
    try:
        #
        start_time = time.time()
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Attempt to publish : Attempt no. {attempt} : Retry no. {attempt-1}")
        # publish returns a tuple (future, packet_id)
        publish_future, packet_id = mqtt_connection.publish(
             topic=TOPIC,
             payload=json.dumps(MESSAGE),
             qos=mqtt.QoS.AT_LEAST_ONCE
        )
        #
        #
        #
        while not publish_future.done():
            elapsed = time.time() - start_time
            # \r returns the cursor to the start of the line to overwrite it
            sys.stdout.write(f"\rSending ... Elapsed time: {elapsed:.2f} seconds")
            sys.stdout.flush()
            time.sleep(0.35)
            if elapsed > TIMEOUT:
                sys.stdout.write(f"\n")
                raise TimeoutError("Publish operation timed out.")
        #
        # Waiting for result
        #
        sys.stdout.write(f"\n")
        res = publish_future.result(timeout=TIMEOUT)
        #
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Attempt no. {attempt} : Retry no. {attempt-1}")
        print(f"Message {res} published successfully to topic : ")
        print(f"{TOPIC}")
        # Final result
        total_time = time.time() - start_time
        print(f"Total time: {total_time:.4f} seconds")
        attempt = RETRIES+2
        #    
    except TimeoutError as e:
        #
        print("time : ", datetime.now(jst_tz))
        print(f"Timeout occurred: {e} : Failed to publish : Attempt no. {attempt} : Retry no. {attempt-1}")
        #
        attempt += 1
        #
        if attempt <= RETRIES+1:
            print("time : ", datetime.now(jst_tz))
            print(f"Attempt no. {attempt} : Retry no. {attempt-1} : Retrying in {INTERVAL} seconds...")
            #time.sleep(INTERVAL)
            start_time = time.perf_counter()
            while True:
                elapsed = time.perf_counter() - start_time
                if elapsed >= INTERVAL:
                    break
                #
                # \r moves the cursor back to the start of the line
                # end="" prevents moving to a new line
                print(f"\rWaiting time: {elapsed:.2f} seconds", end="", flush=True)
                time.sleep(1.0)
            #
            sys.stdout.write(f"\n")
            #
        if attempt > RETRIES+1:
            print("time : ", datetime.now(jst_tz))
            print(f"**\nMaximum RETRY reached. Timeout : Publication failed.\n**")
        #
        #


